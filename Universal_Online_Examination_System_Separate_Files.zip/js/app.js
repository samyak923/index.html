"use strict";

const subjects=[
"School Examination","College / University","Entrance Examination",
"Competitive Examination","Government Examination","Certification Exam",
"Recruitment / Aptitude","Skill Assessment","Mock Test"
];

const bank=[
["School Examination","Which planet is known as the Red Planet?",["Earth","Mars","Jupiter","Venus"],1,"Mars appears reddish because of iron oxide on its surface."],
["School Examination","What is 12 × 8?",["86","96","108","112"],1,"12 multiplied by 8 equals 96."],
["College / University","Which data structure follows LIFO?",["Queue","Stack","Tree","Graph"],1,"A stack follows Last In, First Out."],
["College / University","Which language is primarily used to style web pages?",["HTML","CSS","SQL","XML"],1,"CSS controls presentation and layout."],
["Entrance Examination","If x + 7 = 15, what is x?",["6","7","8","9"],2,"Subtract 7 from both sides: x = 8."],
["Entrance Examination","Which number is prime?",["21","29","35","39"],1,"29 has no positive divisors other than 1 and itself."],
["Competitive Examination","What is 15% of 200?",["20","25","30","35"],2,"0.15 × 200 = 30."],
["Competitive Examination","Choose the synonym of 'rapid'.",["Slow","Quick","Weak","Late"],1,"Quick means fast or rapid."],
["Government Examination","The Constitution of India came into effect on:",["15 August 1947","26 January 1950","26 November 1949","2 October 1950"],1,"The Constitution came into effect on 26 January 1950."],
["Government Examination","Which is the lower house of the Parliament of India?",["Rajya Sabha","Lok Sabha","Vidhan Parishad","Supreme Court"],1,"Lok Sabha is the House of the People."],
["Certification Exam","What does CPU stand for?",["Central Processing Unit","Computer Power Utility","Core Program Unit","Central Program User"],0,"CPU stands for Central Processing Unit."],
["Certification Exam","Which protocol securely transfers web pages?",["HTTP","FTP","HTTPS","SMTP"],2,"HTTPS adds TLS security to HTTP communication."],
["Recruitment / Aptitude","A train travels 60 km in 1.5 hours. Its average speed is:",["30 km/h","40 km/h","45 km/h","60 km/h"],1,"Speed = distance/time = 60/1.5 = 40 km/h."],
["Recruitment / Aptitude","Find the next number: 2, 4, 8, 16, ?",["20","24","32","36"],2,"Each number is doubled, so the next is 32."],
["Skill Assessment","Which shortcut is commonly used to copy selected text on Windows?",["Ctrl+X","Ctrl+C","Ctrl+V","Ctrl+Z"],1,"Ctrl+C copies the selected content."],
["Skill Assessment","Which file format is commonly used for a portable document?",["DOCX","PDF","EXE","CSV"],1,"PDF is designed for portable document presentation."],
["Mock Test","If 5 workers finish a task in 10 days, under the same rate 10 workers would take:",["2 days","5 days","10 days","20 days"],1,"Doubling workers halves the time: 5 days."],
["Mock Test","Which is an example of an input device?",["Monitor","Printer","Keyboard","Speaker"],2,"A keyboard sends input to a computer."],
["College / University","Which keyword is used for inheritance in Java?",["extends","inherits","using","parent"],0,"Java uses extends for class inheritance."],
["Competitive Examination","A Gantt chart is mainly used for:",["Photo editing","Project scheduling","Email delivery","Database backup"],1,"Gantt charts show project tasks against time."]
];

const people=[
["👩‍🎓","Student","Take school, college, entrance and mock examinations."],
["👨‍💻","Candidate","Attempt aptitude, recruitment and skill assessments."],
["👩‍🏫","Teacher","Create and review academic examination content."],
["👨‍🏫","Examiner","Monitor tests, results and performance."],
["👩‍💼","Administrator","Manage examinations, results and system data."]
];

const modules=[
["student","👨‍🎓","Student Registration & Login","Create a student profile and choose an examination."],
["subjects","📚","Subject-wise Examination","Explore all five all examination types and launch an exam."],
["questions","📝","MCQ Question Bank","Browse every question, correct answer and explanation."],
["timer","⏱️","Timer & Auto Submit","Test the working countdown and automatic submission concept."],
["bookmark","🔖","Question Bookmarking","Practice the review and question-palette workflow."],
["evaluation","✅","Automatic Evaluation","Run a live mini evaluation and see the calculated score."],
["grade","🏆","Result & Grade","Understand the percentage and PASS/FAIL grading system."],
["history","📋","Result History","Search, filter, export and manage saved exam attempts."],
["analytics","📊","Performance Analytics","See attempt, pass-rate, average-score and subject statistics."],
["admin","⚙️","Admin Dashboard","Central dashboard for examination monitoring."],
["print","🖨️","Print Result","Print the latest result in a clean mark-sheet format."],
["storage","💾","Browser Local Storage","Inspect and export data saved in this browser."]
];

const state={page:"home",student:null,qs:[],index:0,answers:{},review:{},seconds:600,timer:null,result:null,dark:false};

function esc(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));}
function fmt(s){return String(Math.floor(Math.max(0,s)/60)).padStart(2,"0")+":"+String(Math.max(0,s)%60).padStart(2,"0");}
function getHistory(){try{return JSON.parse(localStorage.getItem("ExamHistory")||"[]")}catch(e){return[]}}
function saveHistory(r){const h=getHistory();h.unshift(r);localStorage.setItem("ExamHistory",JSON.stringify(h.slice(0,300)));}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.style.display="block";clearTimeout(window._toast);window._toast=setTimeout(()=>t.style.display="none",2300);}
function navigate(page){clearInterval(state.timer);state.page=page;render();}
function subjectCount(s){return bank.filter(q=>q[0]===s).length;}
function selectedCount(){return Object.keys(state.answers).length;}

function homeView(){
return `<div class="container">
<section class="hero"><h1> Universal Online Examination System</h1>
<p>A complete multi-examination platform for schools, colleges, universities, entrance tests, competitive exams, government exams, certifications, recruitment and skill assessments. Select an exam, register a candidate and run a fully working timed test.</p>
<div class="heroActions"><button class="btn white" data-go="student">🚀 Start Examination</button><button class="btn soft" data-go="admin">⚙️ Admin Dashboard</button></div></section>
<div class="grid stats">
${[
["Exam Types",subjects.length,"Multiple examination categories"],["Question Bank",bank.length,"Ready-to-use MCQs"],["Exam Duration","10 min","Live countdown"],["Evaluation","AUTO","Instant result"],["Pass Mark","40%","Configurable demo threshold"]
].map(x=>`<div class="card"><div class="statLabel">${x[0]}</div><div class="statValue">${x[1]}</div><div class="statHint">${x[2]}</div></div>`).join("")}</div>
<h2 class="sectionTitle">👥 People & Roles</h2>
<div class="grid">${people.map(p=>`<div class="card" style="display:flex;gap:14px;align-items:flex-start"><div style="width:54px;height:54px;border-radius:16px;background:#ede9fe;display:grid;place-items:center;font-size:30px;flex:none">${p[0]}</div><div><h3 style="margin:0 0 6px">${p[1]}</h3><p style="margin:0;color:var(--muted);font-size:13px;line-height:1.5">${p[2]}</p></div></div>`).join("")}</div>
<h2 class="sectionTitle">Working System Modules</h2>
<div class="grid">${modules.map(m=>`<div class="card module"><div class="moduleIcon">${m[1]}</div><h3>${m[2]}</h3><p>${m[3]}</p><button class="btn soft" data-go="${m[0]}">Open Module →</button></div>`).join("")}</div>
</div>`;
}

function studentView(){
return `<div class="container"><div class="formCard"><h2>👨‍🎓 Student Registration & Login</h2><p class="subtext">Enter valid student details to create an examination session.</p>
<label class="field">Student Name *</label><input class="input" id="studentName" placeholder="e.g. Rahul Sharma" autocomplete="off">
<label class="field">Roll Number *</label><input class="input" id="rollNumber" placeholder="e.g. BCA5-001" autocomplete="off">
<label class="field">Email</label><input class="input" id="studentEmail" type="email" placeholder="student@example.com" autocomplete="off">
<label class="field">Select Examination Type *</label><select class="select" id="studentSubject"><option value="ALL">All Examination Types</option>${subjects.map(s=>`<option>${esc(s)}</option>`).join("")}</select>
<div class="notice">The exam is a local demo: results are stored only in this browser. No server or database is required.</div>
<div class="actions"><button class="btn" id="continueStudent">Continue to Instructions</button><button class="btn soft" data-go="home">Cancel</button></div></div></div>`;
}

function instructionsView(){
return `<div class="container"><div class="card"><div class="pageHead"><div><h2>Examination Instructions</h2><p>Review these rules before starting.</p></div><span class="chip">${esc(state.student.subject==="ALL"?"All Subjects":state.student.subject)}</span></div>
<div class="grid"><div class="card"><h3>⏱️ 10 Minutes</h3><p class="statHint">The countdown starts when the exam begins.</p></div><div class="card"><h3>📝 ${state.qs.length} MCQs</h3><p class="statHint">One correct answer per question.</p></div><div class="card"><h3>🎯 40% Pass</h3><p class="statHint">Score 40% or higher to pass.</p></div></div>
<div class="notice"><b>Student:</b> ${esc(state.student.name)} &nbsp; • &nbsp; <b>Roll:</b> ${esc(state.student.roll)}</div>
<ul style="line-height:2;color:#475569"><li>Use Previous and Next or the question palette.</li><li>Mark questions for review when needed.</li><li>Submit manually or wait for automatic submission at 00:00.</li><li>Do not refresh during an exam.</li></ul>
<div class="actions"><button class="btn green" id="beginExam">Start Exam Now</button><button class="btn soft" data-go="student">Back</button></div></div></div>`;
}

function examView(){
const q=state.qs[state.index],answered=selectedCount(),pct=Math.round(answered/state.qs.length*100);
return `<div class="container"><div class="pageHead"><div><h2>Live Examination</h2><p>${esc(state.student.name)} • ${esc(state.student.roll)} • ${esc(state.student.subject==="ALL"?"All Subjects":state.student.subject)}</p></div><span class="chip">${answered}/${state.qs.length} Answered</span></div>
<div class="examLayout"><section class="examCard"><div class="qTop"><div class="qMeta">QUESTION ${state.index+1} OF ${state.qs.length} • ${esc(q.subject)}</div><span class="chip">${state.review[state.index]?"🔖 Review":""}</span></div><div class="progress" style="margin-top:12px"><i style="width:${pct}%"></i></div>
<div class="question">${esc(q.question)}</div>
${q.options.map((o,k)=>`<label class="option ${state.answers[state.index]===k?"selected":""}"><input type="radio" name="answer" value="${k}" ${state.answers[state.index]===k?"checked":""}> <span><b>${String.fromCharCode(65+k)}.</b> ${esc(o)}</span></label>`).join("")}
<div class="actions noPrint"><button class="btn slate" id="prevQ" ${state.index===0?"disabled":""}>← Previous</button><button class="btn orange" id="reviewQ">${state.review[state.index]?"Unmark Review":"🔖 Mark Review"}</button>${state.index<state.qs.length-1?'<button class="btn" id="nextQ">Next →</button>':'<button class="btn red" id="submitQ">Submit Exam</button>'}</div></section>
<aside class="examSide"><div id="examTimer" class="timer ${state.seconds<=60?"warning":"safe"}">${fmt(state.seconds)}</div><h3>Question Palette</h3><div class="palette">${state.qs.map((_,i)=>`<button class="num ${i===state.index?"current":""} ${state.answers[i]!==undefined?"answered":""} ${state.review[i]?"review":""}" data-jump="${i}">${i+1}</button>`).join("")}</div><div class="notice"><b>${answered}</b> answered<br><b>${state.qs.length-answered}</b> unanswered<br><b>${Object.keys(state.review).filter(k=>state.review[k]).length}</b> for review</div><button class="btn red" style="width:100%" id="submitSide">Submit Exam</button></aside></div></div>`;
}

function resultView(){
const r=state.result;
return `<div class="container"><div class="card resultCard"><h2>🎉 Examination Completed</h2><p>${esc(r.name)} • ${esc(r.roll)}</p><div class="score">${r.percent}%</div><div><span class="badge ${r.status==="PASS"?"pass":"fail"}">${r.status}</span></div><p><b>${r.correct}</b> correct of <b>${r.total}</b> questions</p>
${r.autoSubmit?'<div class="notice dangerBox">⏰ The timer reached zero, so the exam was automatically submitted.</div>':''}
<div class="actions" style="justify-content:center"><button class="btn" id="printLatest">🖨️ Print Result</button><button class="btn green" data-go="student">Take Another Exam</button><button class="btn soft" data-go="home">Home</button></div></div>
<div class="card" style="margin-top:18px"><h3>Mark Sheet</h3><div class="tableWrap"><table class="table"><tbody>
<tr><th>Student Name</th><td>${esc(r.name)}</td></tr><tr><th>Roll Number</th><td>${esc(r.roll)}</td></tr><tr><th>Email</th><td>${esc(r.email||"Not provided")}</td></tr><tr><th>Subject</th><td>${esc(r.subject==="ALL"?"All Examination Types":r.subject)}</td></tr><tr><th>Score</th><td>${r.correct}/${r.total}</td></tr><tr><th>Percentage</th><td>${r.percent}%</td></tr><tr><th>Status</th><td>${r.status}</td></tr><tr><th>Date & Time</th><td>${esc(r.date)}</td></tr></tbody></table></div></div></div>`;
}

function questionsView(){
return `<div class="container"><div class="pageHead"><div><h2>📝 MCQ Question Bank</h2><p>${bank.length} questions • ${subjects.length} examination types</p></div><button class="btn" id="randomPreview">🔀 Random Preview</button></div>
<div class="card"><div class="chips"><button class="btn soft" data-filter="ALL">All (${bank.length})</button>${subjects.map(s=>`<button class="btn soft" data-filter="${esc(s)}">${esc(s)} (${subjectCount(s)})</button>`).join("")}</div><div id="questionList" style="margin-top:14px">${questionList("ALL")}</div></div></div>`;
}
function questionList(filter){
return bank.map((q,i)=>({q,i})).filter(x=>filter==="ALL"||x.q[0]===filter).map(x=>`<div class="card" style="margin:10px 0"><div class="qMeta">Q${x.i+1} • ${esc(x.q[0])}</div><h3>${esc(x.q[1])}</h3><div class="chips">${x.q[2].map((o,k)=>`<span class="chip">${String.fromCharCode(65+k)}. ${esc(o)}${k===x.q[3]?" ✓":""}</span>`).join("")}</div><div class="notice" style="margin-bottom:0"><b>Explanation:</b> ${esc(x.q[4])}</div></div>`).join("")||'<div class="empty">No questions found.</div>';
}

function subjectsView(){
return `<div class="container"><div class="pageHead"><div><h2>📚 Examination Categories</h2><p>Choose any examination type. The same working exam engine is used for every category.</p></div></div>
<div class="grid">${subjects.map((s,i)=>`<div class="card"><div class="moduleIcon">${["🏫","🎓","🎯","🏆","🇮🇳","📜","💼","🛠️","🧪"][i]}</div><h3>${esc(s)}</h3><div class="statValue">${subjectCount(s)}</div><div class="statHint">Questions available</div><button class="btn" data-subject="${esc(s)}" style="margin-top:14px">Start ${esc(s)} →</button></div>`).join("")}</div></div>`;
}

function timerView(){
return `<div class="container"><div class="card" style="max-width:720px;margin:auto;text-align:center"><h2>⏱️ Timer & Auto Submit</h2><p class="subtext">A separate working demonstration of the exam countdown.</p><div id="demoTimer" class="timer safe">10:00</div><div class="actions" style="justify-content:center"><button class="btn" id="demoStart">Start Demo Timer</button><button class="btn orange" id="demoReset">Reset</button></div><div class="notice">In the actual examination, reaching <b>00:00</b> automatically calls the same submit routine used by the Submit Exam button.</div></div></div>`;
}

function bookmarkView(){
return `<div class="container"><div class="card"><h2>🔖 Question Bookmarking</h2><p class="subtext">Click any number to toggle its review state.</p><div class="palette" id="demoPalette">${Array.from({length:15},(_,i)=>`<button class="num" data-demo="${i}">${i+1}</button>`).join("")}</div><div class="notice" id="demoBookmarkStatus">No questions marked for review.</div><div class="actions"><button class="btn" data-go="student">Open Real Exam</button></div></div></div>`;
}

function evaluationView(){
return `<div class="container"><div class="card" style="max-width:850px;margin:auto"><h2>✅ Automatic Evaluation</h2><p class="subtext">This live demo uses the same pass threshold as the real exam.</p><div class="grid">${[1,2,3,4,5].map(i=>`<div class="card"><b>Question ${i}</b><select class="select demoAnswer" id="da${i}" style="margin-top:8px"><option value="">Choose</option><option value="correct">Correct</option><option value="wrong">Wrong</option></select></div>`).join("")}</div><button class="btn" id="calcEval" style="margin-top:15px">Calculate Score</button><div class="notice" id="evalResult">Select answers and calculate.</div></div></div>`;
}

function gradeView(){
return `<div class="container"><div class="pageHead"><div><h2>🏆 Result & Grade</h2><p>Automatic percentage and pass/fail rules.</p></div></div><div class="grid">${[["80–100%","Excellent","pass"],["60–79%","Good","pass"],["40–59%","Pass","pass"],["0–39%","Fail","fail"]].map(x=>`<div class="card"><span class="badge ${x[2]}">${x[1]}</span><h2>${x[0]}</h2><p class="statHint">Calculated automatically after submission.</p></div>`).join("")}</div><div class="notice successBox"><b>Passing rule:</b> Percentage ≥ 40% = PASS. Percentage &lt; 40% = FAIL.</div></div>`;
}

function historyView(){
const h=getHistory();
return `<div class="container"><div class="pageHead"><div><h2>📋 Result History</h2><p>Saved examination attempts from this browser.</p></div><div class="actions noPrint"><button class="btn" id="exportCSV">⬇ Export CSV</button><button class="btn red" id="clearHistory">Clear History</button></div></div><div class="card"><input class="input search" id="historySearch" placeholder="Search name, roll, email, subject or status..."><div id="historyTable">${historyTable(h)}</div></div></div>`;
}
function historyTable(h){
if(!h.length)return '<div class="empty">No results found.</div>';
return `<div class="tableWrap"><table class="table"><thead><tr><th>Name</th><th>Roll</th><th>Subject</th><th>Score</th><th>Status</th><th>Date</th></tr></thead><tbody>${h.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.roll)}</td><td>${esc(r.subject)}</td><td>${r.correct}/${r.total} (${r.percent}%)</td><td><span class="badge ${r.status==="PASS"?"pass":"fail"}">${r.status}</span></td><td>${esc(r.date)}</td></tr>`).join("")}</tbody></table></div>`;
}

function analyticsView(){
const h=getHistory(),pass=h.filter(r=>r.status==="PASS").length,avg=h.length?Math.round(h.reduce((a,r)=>a+r.percent,0)/h.length):0;
return `<div class="container"><div class="pageHead"><div><h2>📊 Performance Analytics</h2><p>Live calculations from saved results.</p></div></div><div class="grid"><div class="card"><div class="statLabel">Total Attempts</div><div class="statValue">${h.length}</div></div><div class="card"><div class="statLabel">Pass Rate</div><div class="statValue">${h.length?Math.round(pass/h.length*100):0}%</div></div><div class="card"><div class="statLabel">Average Score</div><div class="statValue">${avg}%</div></div><div class="card"><div class="statLabel">Question Bank</div><div class="statValue">${bank.length}</div></div></div>
<div class="card" style="margin-top:18px"><h3>Question Distribution by Subject</h3>${subjects.map(s=>{let n=subjectCount(s),w=Math.round(n/bank.length*100);return `<div style="margin:15px 0"><div style="display:flex;justify-content:space-between"><b>${esc(s)}</b><span>${n}</span></div><div class="progress" style="margin-top:6px"><i style="width:${w}%"></i></div></div>`}).join("")}</div></div>`;
}

function adminView(){
const h=getHistory(),pass=h.filter(r=>r.status==="PASS").length,avg=h.length?Math.round(h.reduce((a,r)=>a+r.percent,0)/h.length):0;
return `<div class="container"><section class="hero"><h1>Admin Dashboard</h1><p>Monitor examination attempts, performance and local data from one clean interface.</p><div class="heroActions"><button class="btn white" data-go="history">📋 View Results</button><button class="btn soft" data-go="analytics">📊 Analytics</button></div></section>
<div class="grid stats"><div class="card"><div class="statLabel">Total Attempts</div><div class="statValue">${h.length}</div></div><div class="card"><div class="statLabel">Pass Rate</div><div class="statValue">${h.length?Math.round(pass/h.length*100):0}%</div></div><div class="card"><div class="statLabel">Average Score</div><div class="statValue">${avg}%</div></div><div class="card"><div class="statLabel">Subjects</div><div class="statValue">${subjects.length}</div></div></div>
<div class="card" style="margin-top:18px"><h3>Quick Administration</h3><div class="grid"><button class="card" data-go="questions" style="text-align:left;border:1px solid var(--line)"><b>📝 Question Bank</b><p class="statHint">Browse all ${bank.length} questions across every exam type.</p></button><button class="card" data-go="storage" style="text-align:left;border:1px solid var(--line)"><b>💾 Data Storage</b><p class="statHint">Inspect or export saved data.</p></button><button class="card" data-go="student" style="text-align:left;border:1px solid var(--line)"><b>👨‍🎓 Candidate Exam</b><p class="statHint">Launch a test session.</p></button></div></div></div>`;
}

function storageView(){
const h=getHistory();
return `<div class="container"><div class="card"><div class="pageHead"><div><h2>💾 Browser Local Storage</h2><p>${h.length} saved attempt(s).</p></div><button class="btn" id="downloadJSON">⬇ Export JSON</button></div><div class="notice">Storage key: <b>ExamHistory</b>. This is local browser data; clearing browser site data may remove it.</div><pre class="codeBox">${esc(JSON.stringify(h,null,2))}</pre><div class="actions"><button class="btn red" id="clearStorage">Clear Saved Data</button></div></div></div>`;
}

function printView(){
if(!state.result){return `<div class="container"><div class="card" style="text-align:center"><h2>🖨️ Print Result</h2><p>No latest result is available yet.</p><button class="btn" data-go="student">Start Examination</button></div></div>`}
return `<div class="container"><div class="card"><div class="pageHead"><div><h2>🖨️ Print Result</h2><p>Clean print-ready mark sheet.</p></div><button class="btn noPrint" id="printPage">Print</button></div><div style="border:2px solid #1e293b;padding:25px;text-align:center"><h1> UNIVERSAL ONLINE EXAMINATION SYSTEM</h1><h2>UNIVERSAL ONLINE EXAMINATION • MARK SHEET</h2><hr><table class="table"><tbody><tr><th>Student</th><td>${esc(state.result.name)}</td></tr><tr><th>Roll Number</th><td>${esc(state.result.roll)}</td></tr><tr><th>Subject</th><td>${esc(state.result.subject)}</td></tr><tr><th>Score</th><td>${state.result.correct}/${state.result.total}</td></tr><tr><th>Percentage</th><td>${state.result.percent}%</td></tr><tr><th>Result</th><td>${state.result.status}</td></tr><tr><th>Date</th><td>${esc(state.result.date)}</td></tr></tbody></table></div></div></div>`;
}

function render(){
clearInterval(state.timer);
const views={home:homeView,student:studentView,subjects:subjectsView,questions:questionsView,timer:timerView,bookmark:bookmarkView,evaluation:evaluationView,grade:gradeView,history:historyView,analytics:analyticsView,admin:adminView,storage:storageView,print:printView,instructions:instructionsView,exam:examView,result:resultView};
document.getElementById("app").innerHTML=(views[state.page]||homeView)();
document.querySelectorAll(".navBtn").forEach(b=>b.classList.toggle("active",b.dataset.nav===state.page));
bind();
}

function beginStudent(){
const name=document.getElementById("studentName").value.trim(),roll=document.getElementById("rollNumber").value.trim(),email=document.getElementById("studentEmail").value.trim(),subject=document.getElementById("studentSubject").value;
if(name.length<2){toast("Enter a valid student name.");return}
if(roll.length<2){toast("Enter a valid roll number.");return}
if(email && !/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(email)){toast("Enter a valid email address.");return}
state.student={name,roll,email,subject};
const list=subject==="ALL"?bank:bank.filter(q=>q[0]===subject);
state.qs=list.map(q=>({subject:q[0],question:q[1],options:q[2],correct:q[3],explanation:q[4]}));
state.page="instructions";render();
}

function startExam(){
state.index=0;state.answers={};state.review={};state.seconds=600;state.page="exam";render();
state.timer=setInterval(tick,1000);
}
function tick(){
state.seconds=Math.max(0,state.seconds-1);
const t=document.getElementById("examTimer");if(t){t.textContent=fmt(state.seconds);t.className="timer "+(state.seconds<=60?"warning":"safe")}
if(state.seconds<=0) submitExam(true);
}
function submitExam(auto){
if(!state.qs.length)return;
if(!auto){
const unanswered=state.qs.length-selectedCount();
if(unanswered && !confirm(`There are ${unanswered} unanswered question(s). Submit anyway?`))return;
}
clearInterval(state.timer);
let correct=0;state.qs.forEach((q,i)=>{if(state.answers[i]===q.correct)correct++});
const total=state.qs.length,percent=Math.round(correct/total*100);
state.result={name:state.student.name,roll:state.student.roll,email:state.student.email,subject:state.student.subject,correct,total,percent,status:percent>=40?"PASS":"FAIL",date:new Date().toLocaleString(),autoSubmit:auto};
saveHistory(state.result);state.page="result";render();
toast("Exam submitted successfully.");
}

function bind(){
document.getElementById("homeTop").onclick=()=>navigate("home");
document.getElementById("themeBtn").onclick=()=>{state.dark=!state.dark;document.body.style.background=state.dark?"#0f172a":"var(--bg)";document.body.style.color=state.dark?"#e2e8f0":"var(--ink)";toast(state.dark?"Dark background enabled":"Light background enabled")};

document.querySelectorAll("[data-nav]").forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>navigate(b.dataset.go));

const cs=document.getElementById("continueStudent");if(cs)cs.onclick=beginStudent;
const be=document.getElementById("beginExam");if(be)be.onclick=startExam;

document.querySelectorAll("[data-subject]").forEach(b=>b.onclick=()=>{
state.student={name:"Demo Student",roll:"DEMO-001",email:"demo@example.com",subject:b.dataset.subject};
state.qs=bank.filter(q=>q[0]===b.dataset.subject).map(q=>({subject:q[0],question:q[1],options:q[2],correct:q[3],explanation:q[4]}));
state.page="instructions";render();
});

document.querySelectorAll("[data-filter]").forEach(b=>b.onclick=()=>{const box=document.getElementById("questionList");if(box)box.innerHTML=questionList(b.dataset.filter)});
const rp=document.getElementById("randomPreview");if(rp)rp.onclick=()=>{const shuffled=[...bank].sort(()=>Math.random()-.5).slice(0,5);document.getElementById("questionList").innerHTML=shuffled.map((q,i)=>`<div class="card" style="margin:10px 0"><div class="qMeta">Random ${i+1} • ${esc(q[0])}</div><h3>${esc(q[1])}</h3><p><b>Answer:</b> ${esc(q[2][q[3]])}</p></div>`).join("");toast("Showing 5 random questions.")};

document.querySelectorAll("[data-jump]").forEach(b=>b.onclick=()=>{state.index=Number(b.dataset.jump);render()});
document.querySelectorAll('input[name="answer"]').forEach(x=>x.onchange=()=>{state.answers[state.index]=Number(x.value);render()});
const prev=document.getElementById("prevQ");if(prev)prev.onclick=()=>{if(state.index>0){state.index--;render()}};
const next=document.getElementById("nextQ");if(next)next.onclick=()=>{if(state.index<state.qs.length-1){state.index++;render()}};
const rev=document.getElementById("reviewQ");if(rev)rev.onclick=()=>{state.review[state.index]=!state.review[state.index];render()};
const sub=document.getElementById("submitQ");if(sub)sub.onclick=()=>submitExam(false);
const subs=document.getElementById("submitSide");if(subs)subs.onclick=()=>submitExam(false);
const pr=document.getElementById("printLatest");if(pr)pr.onclick=()=>window.print();
const pp=document.getElementById("printPage");if(pp)pp.onclick=()=>window.print();

const dt=document.getElementById("demoTimer");let demoTimer=null,demoSec=600;
const ds=document.getElementById("demoStart");if(ds)ds.onclick=()=>{clearInterval(demoTimer);demoTimer=setInterval(()=>{demoSec=Math.max(0,demoSec-1);if(dt)dt.textContent=fmt(demoSec);if(demoSec===0){clearInterval(demoTimer);toast("Demo timer finished.")}},1000);toast("Demo timer started.")};
const dr=document.getElementById("demoReset");if(dr)dr.onclick=()=>{clearInterval(demoTimer);demoSec=600;if(dt)dt.textContent="10:00";toast("Demo timer reset.")};

const paletteStatus=document.getElementById("demoBookmarkStatus");document.querySelectorAll("[data-demo]").forEach(b=>b.onclick=()=>{b.classList.toggle("review");const n=document.querySelectorAll("[data-demo].review").length;if(paletteStatus)paletteStatus.innerHTML=n?`<b>${n}</b> question(s) marked for review.`:"No questions marked for review."});

const ce=document.getElementById("calcEval");if(ce)ce.onclick=()=>{const vals=[1,2,3,4,5].map(i=>document.getElementById("da"+i).value);if(vals.some(v=>!v)){toast("Choose an answer for all five demo questions.");return}const c=vals.filter(v=>v==="correct").length,p=Math.round(c/5*100);document.getElementById("evalResult").innerHTML=`Score: <b>${c}/5</b> • Percentage: <b>${p}%</b> • Result: <b>${p>=40?"PASS":"FAIL"}</b>`;document.getElementById("evalResult").className="notice "+(p>=40?"successBox":"dangerBox")};

const hs=document.getElementById("historySearch");if(hs)hs.oninput=()=>{const q=hs.value.toLowerCase();const h=getHistory().filter(r=>(r.name+" "+r.roll+" "+r.email+" "+r.subject+" "+r.status).toLowerCase().includes(q));document.getElementById("historyTable").innerHTML=historyTable(h)};
const ch=document.getElementById("clearHistory");if(ch)ch.onclick=()=>{if(confirm("Clear all examination history from this browser?")){localStorage.removeItem("ExamHistory");render();toast("History cleared.")}};
const ex=document.getElementById("exportCSV");if(ex)ex.onclick=exportCSV;
const dj=document.getElementById("downloadJSON");if(dj)dj.onclick=()=>downloadFile(JSON.stringify(getHistory(),null,2),"_exam_history.json","application/json");
const cst=document.getElementById("clearStorage");if(cst)cst.onclick=()=>{if(confirm("Delete all saved exam data?")){localStorage.removeItem("ExamHistory");render();toast("Saved data deleted.")}};
}

function downloadFile(text,name,type){const blob=new Blob([text],{type});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),500)}
function exportCSV(){
const h=getHistory();if(!h.length){toast("No results to export.");return}
const headers=["Name","Roll","Email","Subject","Correct","Total","Percentage","Status","Date"];
const rows=h.map(r=>[r.name,r.roll,r.email,r.subject,r.correct,r.total,r.percent+"%",r.status,r.date]);
const csv=[headers,...rows].map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\\n");
downloadFile(csv,"_exam_results.csv","text/csv;charset=utf-8");toast("CSV report exported.");
}

document.addEventListener("keydown",e=>{
if(state.page!=="exam")return;
if(e.key==="ArrowLeft"){e.preventDefault();if(state.index>0){state.index--;render()}}
if(e.key==="ArrowRight"){e.preventDefault();if(state.index<state.qs.length-1){state.index++;render()}}
if(e.ctrlKey&&e.key==="Enter"){e.preventDefault();submitExam(false)}
});

window.addEventListener("error",e=>toast("A page error was detected. Please reload the website."));
render();
