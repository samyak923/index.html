# Universal Online Examination System

## Folder structure

- index.html — main website page
- css/style.css — all website styling
- js/app.js — all examination logic, questions, navigation, timer, evaluation, results and local storage

## Run locally

Open `index.html` directly in Chrome or Edge.

## GitHub Pages

Upload the entire folder while preserving the `css` and `js` folders. GitHub Pages should use `index.html` as the entry page.

## Important

This is a browser/local-storage prototype. Examination history is stored in the browser. A production multi-user system requires a backend, database, secure authentication, server-side timing and authorization.
